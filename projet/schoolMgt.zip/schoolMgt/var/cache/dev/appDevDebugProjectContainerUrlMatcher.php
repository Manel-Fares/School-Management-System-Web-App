<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = [];
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_wdt']), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not__profiler_home;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', '_profiler_home'));
                    }

                    return $ret;
                }
                not__profiler_home:

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_search_results']), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler']), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_router']), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception']), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception_css']), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_twig_error_test']), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        elseif (0 === strpos($pathinfo, '/a')) {
            if (0 === strpos($pathinfo, '/absence')) {
                // absence_index
                if ('/absence' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'ClassBundle\\Controller\\AbsenceController::indexAction',  '_route' => 'absence_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_absence_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'absence_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_absence_index;
                    }

                    return $ret;
                }
                not_absence_index:

                // absence_show
                if (preg_match('#^/absence/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'absence_show']), array (  '_controller' => 'ClassBundle\\Controller\\AbsenceController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_absence_show;
                    }

                    return $ret;
                }
                not_absence_show:

                // absence_new
                if ('/absence/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'ClassBundle\\Controller\\AbsenceController::newAction',  '_route' => 'absence_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_absence_new;
                    }

                    return $ret;
                }
                not_absence_new:

                // absence_edit
                if (preg_match('#^/absence/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'absence_edit']), array (  '_controller' => 'ClassBundle\\Controller\\AbsenceController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_absence_edit;
                    }

                    return $ret;
                }
                not_absence_edit:

                // absence_delete
                if (preg_match('#^/absence/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'absence_delete']), array (  '_controller' => 'ClassBundle\\Controller\\AbsenceController::deleteAction',));
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_absence_delete;
                    }

                    return $ret;
                }
                not_absence_delete:

                // absence_deleteC
                if (0 === strpos($pathinfo, '/absence/delete') && preg_match('#^/absence/delete/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'absence_deleteC']), array (  '_controller' => 'ClassBundle\\Controller\\AbsenceController::deleteCAction',));
                }

            }

            // abcenseetud
            if ('/absetud' === $pathinfo) {
                return array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::getAbsenceAction',  '_route' => 'abcenseetud',);
            }

            if (0 === strpos($pathinfo, '/affct')) {
                // affct
                if (preg_match('#^/affct/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'affct']), array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::affectAction',));
                }

                // affctense
                if (0 === strpos($pathinfo, '/affctense') && preg_match('#^/affctense/(?P<id>[^/]++)/(?P<idmat>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'affctense']), array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::affectEnseiAction',));
                }

            }

            elseif (0 === strpos($pathinfo, '/add')) {
                // admin
                if ('/add' === $pathinfo) {
                    return array (  '_controller' => 'ForumBundle\\Controller\\QuestionController::addQuestionAction',  '_route' => 'admin',);
                }

                // add_question
                if ('/add/question' === $pathinfo) {
                    return array (  '_controller' => 'ForumBundle\\Controller\\QuestionController::addQuestionAction',  '_route' => 'add_question',);
                }

            }

            elseif (0 === strpos($pathinfo, '/api/threads')) {
                // fos_comment_new_threads
                if (0 === strpos($pathinfo, '/api/threads/new') && preg_match('#^/api/threads/new(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_new_threads']), array (  '_controller' => 'fos_comment.controller.thread:newThreadsAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_new_threads;
                    }

                    return $ret;
                }
                not_fos_comment_new_threads:

                // fos_comment_edit_thread_commentable
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/commentable/edit(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_edit_thread_commentable']), array (  '_controller' => 'fos_comment.controller.thread:editThreadCommentableAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_edit_thread_commentable;
                    }

                    return $ret;
                }
                not_fos_comment_edit_thread_commentable:

                // fos_comment_new_thread_comments
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments/new(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_new_thread_comments']), array (  '_controller' => 'fos_comment.controller.thread:newThreadCommentsAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_new_thread_comments;
                    }

                    return $ret;
                }
                not_fos_comment_new_thread_comments:

                // fos_comment_remove_thread_comment
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments/(?P<commentId>[^/]++)/remove(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_remove_thread_comment']), array (  '_controller' => 'fos_comment.controller.thread:removeThreadCommentAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_remove_thread_comment;
                    }

                    return $ret;
                }
                not_fos_comment_remove_thread_comment:

                // fos_comment_edit_thread_comment
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments/(?P<commentId>[^/]++)/edit(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_edit_thread_comment']), array (  '_controller' => 'fos_comment.controller.thread:editThreadCommentAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_edit_thread_comment;
                    }

                    return $ret;
                }
                not_fos_comment_edit_thread_comment:

                // fos_comment_new_thread_comment_votes
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments/(?P<commentId>[^/]++)/votes/new(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_new_thread_comment_votes']), array (  '_controller' => 'fos_comment.controller.thread:newThreadCommentVotesAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_new_thread_comment_votes;
                    }

                    return $ret;
                }
                not_fos_comment_new_thread_comment_votes:

                // fos_comment_get_thread
                if (preg_match('#^/api/threads/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_get_thread']), array (  '_controller' => 'fos_comment.controller.thread:getThreadAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_get_thread;
                    }

                    return $ret;
                }
                not_fos_comment_get_thread:

                // fos_comment_get_threads
                if (preg_match('#^/api/threads(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_get_threads']), array (  '_controller' => 'fos_comment.controller.thread:getThreadsActions',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_get_threads;
                    }

                    return $ret;
                }
                not_fos_comment_get_threads:

                // fos_comment_post_threads
                if (preg_match('#^/api/threads(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_post_threads']), array (  '_controller' => 'fos_comment.controller.thread:postThreadsAction',  '_format' => 'html',));
                    if (!in_array($requestMethod, ['POST'])) {
                        $allow = array_merge($allow, ['POST']);
                        goto not_fos_comment_post_threads;
                    }

                    return $ret;
                }
                not_fos_comment_post_threads:

                // fos_comment_patch_thread_commentable
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/commentable(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_patch_thread_commentable']), array (  '_controller' => 'fos_comment.controller.thread:patchThreadCommentableAction',  '_format' => 'html',));
                    if (!in_array($requestMethod, ['PATCH'])) {
                        $allow = array_merge($allow, ['PATCH']);
                        goto not_fos_comment_patch_thread_commentable;
                    }

                    return $ret;
                }
                not_fos_comment_patch_thread_commentable:

                // fos_comment_get_thread_comment
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments/(?P<commentId>[^/\\.]++)(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_get_thread_comment']), array (  '_controller' => 'fos_comment.controller.thread:getThreadCommentAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_get_thread_comment;
                    }

                    return $ret;
                }
                not_fos_comment_get_thread_comment:

                // fos_comment_patch_thread_comment_state
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments/(?P<commentId>[^/]++)/state(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_patch_thread_comment_state']), array (  '_controller' => 'fos_comment.controller.thread:patchThreadCommentStateAction',  '_format' => 'html',));
                    if (!in_array($requestMethod, ['PATCH'])) {
                        $allow = array_merge($allow, ['PATCH']);
                        goto not_fos_comment_patch_thread_comment_state;
                    }

                    return $ret;
                }
                not_fos_comment_patch_thread_comment_state:

                // fos_comment_put_thread_comments
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments/(?P<commentId>[^/\\.]++)(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_put_thread_comments']), array (  '_controller' => 'fos_comment.controller.thread:putThreadCommentsAction',  '_format' => 'html',));
                    if (!in_array($requestMethod, ['PUT'])) {
                        $allow = array_merge($allow, ['PUT']);
                        goto not_fos_comment_put_thread_comments;
                    }

                    return $ret;
                }
                not_fos_comment_put_thread_comments:

                // fos_comment_get_thread_comments
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_get_thread_comments']), array (  '_controller' => 'fos_comment.controller.thread:getThreadCommentsAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_get_thread_comments;
                    }

                    return $ret;
                }
                not_fos_comment_get_thread_comments:

                // fos_comment_post_thread_comments
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_post_thread_comments']), array (  '_controller' => 'fos_comment.controller.thread:postThreadCommentsAction',  '_format' => 'html',));
                    if (!in_array($requestMethod, ['POST'])) {
                        $allow = array_merge($allow, ['POST']);
                        goto not_fos_comment_post_thread_comments;
                    }

                    return $ret;
                }
                not_fos_comment_post_thread_comments:

                // fos_comment_get_thread_comment_votes
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments/(?P<commentId>[^/]++)/votes(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_get_thread_comment_votes']), array (  '_controller' => 'fos_comment.controller.thread:getThreadCommentVotesAction',  '_format' => 'html',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_comment_get_thread_comment_votes;
                    }

                    return $ret;
                }
                not_fos_comment_get_thread_comment_votes:

                // fos_comment_post_thread_comment_votes
                if (preg_match('#^/api/threads/(?P<id>[^/]++)/comments/(?P<commentId>[^/]++)/votes(?:\\.(?P<_format>json|xml|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_comment_post_thread_comment_votes']), array (  '_controller' => 'fos_comment.controller.thread:postThreadCommentVotesAction',  '_format' => 'html',));
                    if (!in_array($requestMethod, ['POST'])) {
                        $allow = array_merge($allow, ['POST']);
                        goto not_fos_comment_post_thread_comment_votes;
                    }

                    return $ret;
                }
                not_fos_comment_post_thread_comment_votes:

            }

            elseif (0 === strpos($pathinfo, '/answer')) {
                // edit_answer
                if (preg_match('#^/answer/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'edit_answer']), array (  '_controller' => 'ForumBundle\\Controller\\AnswerController::editAnswerAction',));
                }

                // delete_answer
                if (preg_match('#^/answer/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'delete_answer']), array (  '_controller' => 'ForumBundle\\Controller\\AnswerController::deleteAnswerAction',));
                }

                // answer_vote
                if (preg_match('#^/answer/(?P<id>[^/]++)/vote/(?P<vote>▲|▼)$#sDu', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'answer_vote']), array (  '_controller' => 'ForumBundle\\Controller\\AnswerController::voteAction',));
                }

            }

        }

        elseif (0 === strpos($pathinfo, '/c')) {
            if (0 === strpos($pathinfo, '/class')) {
                // classe_index
                if ('/class' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'ClassBundle\\Controller\\ClasseController::indexAction',  '_route' => 'classe_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_classe_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'classe_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_classe_index;
                    }

                    return $ret;
                }
                not_classe_index:

                // classe_show
                if (preg_match('#^/class/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'classe_show']), array (  '_controller' => 'ClassBundle\\Controller\\ClasseController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_classe_show;
                    }

                    return $ret;
                }
                not_classe_show:

                // classe_new
                if ('/class/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'ClassBundle\\Controller\\ClasseController::newAction',  '_route' => 'classe_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_classe_new;
                    }

                    return $ret;
                }
                not_classe_new:

                // classe_edit
                if (preg_match('#^/class/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'classe_edit']), array (  '_controller' => 'ClassBundle\\Controller\\ClasseController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_classe_edit;
                    }

                    return $ret;
                }
                not_classe_edit:

                // classe_delete
                if (preg_match('#^/class/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'classe_delete']), array (  '_controller' => 'ClassBundle\\Controller\\ClasseController::deleteAction',));
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_classe_delete;
                    }

                    return $ret;
                }
                not_classe_delete:

                // classe_deleteC
                if (0 === strpos($pathinfo, '/class/delete') && preg_match('#^/class/delete/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'classe_deleteC']), array (  '_controller' => 'ClassBundle\\Controller\\ClasseController::deleteCAction',));
                }

            }

            elseif (0 === strpos($pathinfo, '/club')) {
                // club_index
                if ('/club' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'EvenementBundle\\Controller\\ClubController::indexAction',  '_route' => 'club_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_club_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'club_index'));
                    }

                    return $ret;
                }
                not_club_index:

                // club_show_image
                if ('/club/ListImage' === $pathinfo) {
                    return array (  '_controller' => 'EvenementBundle\\Controller\\ClubController::ListImageAction',  '_route' => 'club_show_image',);
                }

                // club_new
                if ('/club/new' === $pathinfo) {
                    return array (  '_controller' => 'EvenementBundle\\Controller\\ClubController::newAction',  '_route' => 'club_new',);
                }

                // club_show
                if (preg_match('#^/club/(?P<idclub>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'club_show']), array (  '_controller' => 'EvenementBundle\\Controller\\ClubController::showAction',));
                }

                // club_edit
                if (preg_match('#^/club/(?P<idclub>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'club_edit']), array (  '_controller' => 'EvenementBundle\\Controller\\ClubController::editAction',));
                }

                // club_delete
                if (preg_match('#^/club/(?P<idclub>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'club_delete']), array (  '_controller' => 'EvenementBundle\\Controller\\ClubController::deleteAction',));
                }

            }

            elseif (0 === strpos($pathinfo, '/calendar')) {
                // calend_index
                if ('/calendar' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'ClassBundle\\Controller\\CalendarannuelController::indexAction',  '_route' => 'calend_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_calend_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'calend_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_calend_index;
                    }

                    return $ret;
                }
                not_calend_index:

                // calend_show
                if (preg_match('#^/calendar/(?P<id>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'calend_show']), array (  '_controller' => 'ClassBundle\\Controller\\CalendarannuelController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_calend_show;
                    }

                    return $ret;
                }
                not_calend_show:

                // calend_new
                if ('/calendar/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'ClassBundle\\Controller\\CalendarannuelController::newAction',  '_route' => 'calend_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_calend_new;
                    }

                    return $ret;
                }
                not_calend_new:

                // calend_edit
                if (preg_match('#^/calendar/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'calend_edit']), array (  '_controller' => 'ClassBundle\\Controller\\CalendarannuelController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_calend_edit;
                    }

                    return $ret;
                }
                not_calend_edit:

                // calend_delete
                if (preg_match('#^/calendar/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'calend_delete']), array (  '_controller' => 'ClassBundle\\Controller\\CalendarannuelController::deleteAction',));
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_calend_delete;
                    }

                    return $ret;
                }
                not_calend_delete:

            }

        }

        elseif (0 === strpos($pathinfo, '/e')) {
            if (0 === strpos($pathinfo, '/emploi')) {
                // emplo_index
                if ('/emploi' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'ClassBundle\\Controller\\EmploisController::indexAction',  '_route' => 'emplo_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_emplo_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'emplo_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_emplo_index;
                    }

                    return $ret;
                }
                not_emplo_index:

                // emplo_show
                if (preg_match('#^/emploi/(?P<idemplois>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'emplo_show']), array (  '_controller' => 'ClassBundle\\Controller\\EmploisController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_emplo_show;
                    }

                    return $ret;
                }
                not_emplo_show:

                // emplo_new
                if ('/emploi/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'ClassBundle\\Controller\\EmploisController::newAction',  '_route' => 'emplo_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_emplo_new;
                    }

                    return $ret;
                }
                not_emplo_new:

                // emplo_edit
                if (preg_match('#^/emploi/(?P<idemplois>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'emplo_edit']), array (  '_controller' => 'ClassBundle\\Controller\\EmploisController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_emplo_edit;
                    }

                    return $ret;
                }
                not_emplo_edit:

                // emplo_delete
                if (preg_match('#^/emploi/(?P<idemplois>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'emplo_delete']), array (  '_controller' => 'ClassBundle\\Controller\\EmploisController::deleteAction',));
                    if (!in_array($requestMethod, ['DELETE'])) {
                        $allow = array_merge($allow, ['DELETE']);
                        goto not_emplo_delete;
                    }

                    return $ret;
                }
                not_emplo_delete:

                // emplo_deleteC
                if (0 === strpos($pathinfo, '/emploi/delete') && preg_match('#^/emploi/delete/(?P<idemplois>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'emplo_deleteC']), array (  '_controller' => 'ClassBundle\\Controller\\EmploisController::deleteCAction',));
                }

            }

            // empleetud
            if ('/empletud' === $pathinfo) {
                return array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::getEmploisAction',  '_route' => 'empleetud',);
            }

            // affectEtudClass
            if ('/etds' === $pathinfo) {
                return array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::affetudiclassAction',  '_route' => 'affectEtudClass',);
            }

            // affctens
            if ('/ens' === $pathinfo) {
                return array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::affenseigclassAction',  '_route' => 'affctens',);
            }

            if (0 === strpos($pathinfo, '/evenement')) {
                // evenement_index
                if ('/evenement' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'EvenementBundle\\Controller\\EvenementController::indexAction',  '_route' => 'evenement_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_evenement_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'evenement_index'));
                    }

                    return $ret;
                }
                not_evenement_index:

                // EvenementClub
                if ('/evenement/afficherEvenementClub' === $pathinfo) {
                    return array (  '_controller' => 'EvenementBundle\\Controller\\EvenementController::afficherEvenementClubAction',  '_route' => 'EvenementClub',);
                }

                // evenement_image
                if ('/evenement/image' === $pathinfo) {
                    return array (  '_controller' => 'EvenementBundle\\Controller\\EvenementController::ListImageAction',  '_route' => 'evenement_image',);
                }

                // evenement_detail
                if (0 === strpos($pathinfo, '/evenement/detailevenement') && preg_match('#^/evenement/detailevenement/(?P<idevenement>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'evenement_detail']), array (  '_controller' => 'EvenementBundle\\Controller\\EvenementController::ListImageDetailAction',));
                }

                // evenement_Proche
                if ('/evenement/EvenementProche' === $pathinfo) {
                    return array (  '_controller' => 'EvenementBundle\\Controller\\EvenementController::EvenementProAction',  '_route' => 'evenement_Proche',);
                }

                // evenement_new
                if ('/evenement/new' === $pathinfo) {
                    return array (  '_controller' => 'EvenementBundle\\Controller\\EvenementController::newAction',  '_route' => 'evenement_new',);
                }

                // evenement_show
                if (preg_match('#^/evenement/(?P<idevenement>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'evenement_show']), array (  '_controller' => 'EvenementBundle\\Controller\\EvenementController::showAction',));
                }

                // evenement_edit
                if (preg_match('#^/evenement/(?P<idevenement>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'evenement_edit']), array (  '_controller' => 'EvenementBundle\\Controller\\EvenementController::editAction',));
                }

                // evenement_delete
                if (preg_match('#^/evenement/(?P<idevenement>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'evenement_delete']), array (  '_controller' => 'EvenementBundle\\Controller\\EvenementController::deleteAction',));
                }

            }

        }

        // class_homepage
        if ('/indexClass' === $pathinfo) {
            return array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::indexAction',  '_route' => 'class_homepage',);
        }

        if (0 === strpos($pathinfo, '/p')) {
            // pdf
            if ('/pdf' === $pathinfo) {
                return array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::PDFAction',  '_route' => 'pdf',);
            }

            if (0 === strpos($pathinfo, '/personel')) {
                if (0 === strpos($pathinfo, '/personel/answer')) {
                    // answers_listing_admin
                    if ('/personel/answers' === $trimmedPathinfo) {
                        $ret = array (  '_controller' => 'ForumBundle\\Controller\\AdminController::answersListingAdminAction',  '_route' => 'answers_listing_admin',);
                        if ('/' === substr($pathinfo, -1)) {
                            // no-op
                        } elseif ('GET' !== $canonicalMethod) {
                            goto not_answers_listing_admin;
                        } else {
                            return array_replace($ret, $this->redirect($rawPathinfo.'/', 'answers_listing_admin'));
                        }

                        return $ret;
                    }
                    not_answers_listing_admin:

                    // answer_valid
                    if (preg_match('#^/personel/answer/(?P<id>[^/]++)/valid$#sD', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, ['_route' => 'answer_valid']), array (  '_controller' => 'ForumBundle\\Controller\\AdminController::validAnswerAction',));
                    }

                }

                // openquest
                if (0 === strpos($pathinfo, '/personel/open') && preg_match('#^/personel/open/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'openquest']), array (  '_controller' => 'ForumBundle\\Controller\\AdminController::opensAction',));
                }

                // closeques
                if (0 === strpos($pathinfo, '/personel/close') && preg_match('#^/personel/close/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'closeques']), array (  '_controller' => 'ForumBundle\\Controller\\AdminController::closesAction',));
                }

                // banUser
                if (0 === strpos($pathinfo, '/personel/ban') && preg_match('#^/personel/ban/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'banUser']), array (  '_controller' => 'ForumBundle\\Controller\\AdminController::banUserAction',));
                }

                // unbanUser
                if (0 === strpos($pathinfo, '/personel/unban') && preg_match('#^/personel/unban/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'unbanUser']), array (  '_controller' => 'ForumBundle\\Controller\\AdminController::unbanUserAction',));
                }

                // chartPieAction
                if ('/personel/stat' === $pathinfo) {
                    return array (  '_controller' => 'ForumBundle\\Controller\\AdminController::chartPieAction',  '_route' => 'chartPieAction',);
                }

            }

            elseif (0 === strpos($pathinfo, '/profile')) {
                // fos_user_profile_show
                if ('/profile' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'fos_user.profile.controller:showAction',  '_route' => 'fos_user_profile_show',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_fos_user_profile_show;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'fos_user_profile_show'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_user_profile_show;
                    }

                    return $ret;
                }
                not_fos_user_profile_show:

                // fos_user_profile_edit
                if ('/profile/edit' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.profile.controller:editAction',  '_route' => 'fos_user_profile_edit',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_fos_user_profile_edit;
                    }

                    return $ret;
                }
                not_fos_user_profile_edit:

                // fos_user_change_password
                if ('/profile/change-password' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.change_password.controller:changePasswordAction',  '_route' => 'fos_user_change_password',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_fos_user_change_password;
                    }

                    return $ret;
                }
                not_fos_user_change_password:

            }

            elseif (0 === strpos($pathinfo, '/participation')) {
                // participation_index
                if ('/participation' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'EvenementBundle\\Controller\\ParticipationController::indexAction',  '_route' => 'participation_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_participation_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'participation_index'));
                    }

                    return $ret;
                }
                not_participation_index:

                // participation_new
                if (0 === strpos($pathinfo, '/participation/new') && preg_match('#^/participation/new/(?P<idevenement>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'participation_new']), array (  '_controller' => 'EvenementBundle\\Controller\\ParticipationController::newAction',));
                }

                // participation_show
                if (preg_match('#^/participation/(?P<idparticipation>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'participation_show']), array (  '_controller' => 'EvenementBundle\\Controller\\ParticipationController::showAction',));
                }

                // participation_edit
                if (preg_match('#^/participation/(?P<idparticipation>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'participation_edit']), array (  '_controller' => 'EvenementBundle\\Controller\\ParticipationController::editAction',));
                }

                // participation_delete
                if (preg_match('#^/participation/(?P<idparticipation>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'participation_delete']), array (  '_controller' => 'EvenementBundle\\Controller\\ParticipationController::deleteAction',));
                }

            }

        }

        // projet_indexPdf
        if ('/Pdfff' === $pathinfo) {
            $ret = array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::indexPdfAction',  '_route' => 'projet_indexPdf',);
            if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                $allow = array_merge($allow, ['GET', 'POST']);
                goto not_projet_indexPdf;
            }

            return $ret;
        }
        not_projet_indexPdf:

        // search
        if ('/search' === $pathinfo) {
            return array (  '_controller' => 'ClassBundle\\Controller\\DefaultController::liveSearchAction',  '_route' => 'search',);
        }

        if (0 === strpos($pathinfo, '/school')) {
            // school_homepage
            if ('/school/home' === $pathinfo) {
                return array (  '_controller' => 'schoolBundle\\Controller\\DefaultController::indexAction',  '_route' => 'school_homepage',);
            }

            // school_map
            if ('/school/map' === $pathinfo) {
                return array (  '_controller' => 'schoolBundle\\Controller\\DefaultController::mapAction',  '_route' => 'school_map',);
            }

            // add
            if ('/school/addUser' === $pathinfo) {
                return array (  '_controller' => 'schoolBundle\\Controller\\securityController::addAction',  '_route' => 'add',);
            }

            // redirect
            if ('/school/redirect' === $pathinfo) {
                return array (  '_controller' => 'schoolBundle\\Controller\\securityController::redirectAction',  '_route' => 'redirect',);
            }

        }

        // forum_homepage
        if ('/forumindex' === $pathinfo) {
            return array (  '_controller' => 'ForumBundle\\Controller\\DefaultController::indexAction',  '_route' => 'forum_homepage',);
        }

        // ancarebeca_full_calendar_load
        if ('/full-calendar/load' === $pathinfo) {
            return array (  '_controller' => 'AncaRebeca\\FullCalendarBundle\\Controller\\CalendarController::loadAction',  '_route' => 'ancarebeca_full_calendar_load',);
        }

        if (0 === strpos($pathinfo, '/books')) {
            // books_index
            if ('/books/books' === $pathinfo) {
                $ret = array (  '_controller' => 'BooksBundle\\Controller\\BooksController::indexAction',  '_route' => 'books_index',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_books_index;
                }

                return $ret;
            }
            not_books_index:

            // books_backindex
            if ('/books/backbooks' === $pathinfo) {
                $ret = array (  '_controller' => 'BooksBundle\\Controller\\BooksController::backindexAction',  '_route' => 'books_backindex',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_books_backindex;
                }

                return $ret;
            }
            not_books_backindex:

            // books_charts
            if ('/books/charts' === $pathinfo) {
                $ret = array (  '_controller' => 'BooksBundle\\Controller\\BooksController::chartsAction',  '_route' => 'books_charts',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_books_charts;
                }

                return $ret;
            }
            not_books_charts:

            // books_show
            if (preg_match('#^/books/(?P<idbook>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'books_show']), array (  '_controller' => 'BooksBundle\\Controller\\BooksController::commentBookAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_books_show;
                }

                return $ret;
            }
            not_books_show:

            // books_filtrage
            if (preg_match('#^/books/(?P<categoriebook>[^/]++)/showbooks$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'books_filtrage']), array (  '_controller' => 'BooksBundle\\Controller\\BooksController::filtrageAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_books_filtrage;
                }

                return $ret;
            }
            not_books_filtrage:

            // books_new
            if ('/books/new' === $pathinfo) {
                $ret = array (  '_controller' => 'BooksBundle\\Controller\\BooksController::newAction',  '_route' => 'books_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_books_new;
                }

                return $ret;
            }
            not_books_new:

            // books_edit
            if (preg_match('#^/books/(?P<idbook>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'books_edit']), array (  '_controller' => 'BooksBundle\\Controller\\BooksController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_books_edit;
                }

                return $ret;
            }
            not_books_edit:

            // books_delete
            if (preg_match('#^/books/(?P<idbook>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'books_delete']), array (  '_controller' => 'BooksBundle\\Controller\\BooksController::deleteAction',));
                if (!in_array($requestMethod, ['DELETE'])) {
                    $allow = array_merge($allow, ['DELETE']);
                    goto not_books_delete;
                }

                return $ret;
            }
            not_books_delete:

            // wishliste_add
            if (preg_match('#^/books/(?P<idbook>[^/]++)/add$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'wishliste_add']), array (  '_controller' => 'BooksBundle\\Controller\\WishlisteController::addAction',));
            }

            // wishliste_index
            if ('/books/listeBooks' === $pathinfo) {
                $ret = array (  '_controller' => 'BooksBundle\\Controller\\WishlisteController::indexAction',  '_route' => 'wishliste_index',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_wishliste_index;
                }

                return $ret;
            }
            not_wishliste_index:

            // wishliste_new
            if ('/books/new' === $pathinfo) {
                $ret = array (  '_controller' => 'BooksBundle\\Controller\\WishlisteController::newAction',  '_route' => 'wishliste_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_wishliste_new;
                }

                return $ret;
            }
            not_wishliste_new:

            // wishliste_show
            if (preg_match('#^/books/(?P<idlist>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'wishliste_show']), array (  '_controller' => 'BooksBundle\\Controller\\WishlisteController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_wishliste_show;
                }

                return $ret;
            }
            not_wishliste_show:

            // wishliste_edit
            if (preg_match('#^/books/(?P<idlist>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'wishliste_edit']), array (  '_controller' => 'BooksBundle\\Controller\\WishlisteController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_wishliste_edit;
                }

                return $ret;
            }
            not_wishliste_edit:

            // wishliste_delete
            if (preg_match('#^/books/(?P<idbook>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'wishliste_delete']), array (  '_controller' => 'BooksBundle\\Controller\\WishlisteController::deleteAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_wishliste_delete;
                }

                return $ret;
            }
            not_wishliste_delete:

            // reservationbook_add
            if (preg_match('#^/books/(?P<idbook>[^/]++)/addreservation$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'reservationbook_add']), array (  '_controller' => 'BooksBundle\\Controller\\ReservationbookController::addAction',));
            }

            // reservationbook_index
            if ('/books' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'BooksBundle\\Controller\\ReservationbookController::indexAction',  '_route' => 'reservationbook_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_reservationbook_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'reservationbook_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_reservationbook_index;
                }

                return $ret;
            }
            not_reservationbook_index:

            // reservationbook_show
            if (preg_match('#^/books/(?P<idreservation>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reservationbook_show']), array (  '_controller' => 'BooksBundle\\Controller\\ReservationbookController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_reservationbook_show;
                }

                return $ret;
            }
            not_reservationbook_show:

            // reservationbook_new
            if ('/books/new' === $pathinfo) {
                $ret = array (  '_controller' => 'BooksBundle\\Controller\\ReservationbookController::newAction',  '_route' => 'reservationbook_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_reservationbook_new;
                }

                return $ret;
            }
            not_reservationbook_new:

            // reservationbook_edit
            if (preg_match('#^/books/(?P<idreservation>[^/]++)/editreservation$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reservationbook_edit']), array (  '_controller' => 'BooksBundle\\Controller\\ReservationbookController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_reservationbook_edit;
                }

                return $ret;
            }
            not_reservationbook_edit:

            // reservationbook_delete
            if (preg_match('#^/books/(?P<idreservation>[^/]++)/deletereservation$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reservationbook_delete']), array (  '_controller' => 'BooksBundle\\Controller\\ReservationbookController::deleteReservationAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_reservationbook_delete;
                }

                return $ret;
            }
            not_reservationbook_delete:

            // likes_delete
            if (preg_match('#^/books/(?P<idlike>[^/]++)/deleteLike$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'likes_delete']), array (  '_controller' => 'BooksBundle\\Controller\\LikesController::deleteLikeAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_likes_delete;
                }

                return $ret;
            }
            not_likes_delete:

            // likes_add
            if (preg_match('#^/books/(?P<idbook>[^/]++)/addlike$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'likes_add']), array (  '_controller' => 'BooksBundle\\Controller\\LikesController::addAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_likes_add;
                }

                return $ret;
            }
            not_likes_add:

        }

        // books_homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'BooksBundle\\Controller\\DefaultController::indexAction',  '_route' => 'books_homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_books_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'books_homepage'));
            }

            return $ret;
        }
        not_books_homepage:

        if (0 === strpos($pathinfo, '/re')) {
            if (0 === strpos($pathinfo, '/reclamation')) {
                // reclamation_index
                if ('/reclamation' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'ReclamationBundle\\Controller\\ReclamationController::indexAction',  '_route' => 'reclamation_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_reclamation_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'reclamation_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_reclamation_index;
                    }

                    return $ret;
                }
                not_reclamation_index:

                // reclamation_backindex
                if ('/reclamation/backindex' === $pathinfo) {
                    $ret = array (  '_controller' => 'ReclamationBundle\\Controller\\ReclamationController::backindexAction',  '_route' => 'reclamation_backindex',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_reclamation_backindex;
                    }

                    return $ret;
                }
                not_reclamation_backindex:

                // reclamation_show
                if (preg_match('#^/reclamation/(?P<idreclamation>[^/]++)/show$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reclamation_show']), array (  '_controller' => 'ReclamationBundle\\Controller\\ReclamationController::showAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_reclamation_show;
                    }

                    return $ret;
                }
                not_reclamation_show:

                // reclamation_new
                if ('/reclamation/new' === $pathinfo) {
                    $ret = array (  '_controller' => 'ReclamationBundle\\Controller\\ReclamationController::newAction',  '_route' => 'reclamation_new',);
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_reclamation_new;
                    }

                    return $ret;
                }
                not_reclamation_new:

                // reclamation_edit
                if (preg_match('#^/reclamation/(?P<idreclamation>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reclamation_edit']), array (  '_controller' => 'ReclamationBundle\\Controller\\ReclamationController::editAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_reclamation_edit;
                    }

                    return $ret;
                }
                not_reclamation_edit:

                // reclamation_backedit
                if (preg_match('#^/reclamation/(?P<idreclamation>[^/]++)/backedit$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reclamation_backedit']), array (  '_controller' => 'ReclamationBundle\\Controller\\ReclamationController::editStatusAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_reclamation_backedit;
                    }

                    return $ret;
                }
                not_reclamation_backedit:

                // reclamation_delete
                if (preg_match('#^/reclamation/(?P<idreclamation>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reclamation_delete']), array (  '_controller' => 'ReclamationBundle\\Controller\\ReclamationController::deleteAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_reclamation_delete;
                    }

                    return $ret;
                }
                not_reclamation_delete:

                // reclamation_sendmail
                if (preg_match('#^/reclamation/(?P<idreclamation>[^/]++)/sendmail$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'reclamation_sendmail']), array (  '_controller' => 'ReclamationBundle\\Controller\\ReclamationController::sendEmailAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_reclamation_sendmail;
                    }

                    return $ret;
                }
                not_reclamation_sendmail:

            }

            elseif (0 === strpos($pathinfo, '/resultat')) {
                // resultat_index
                if ('/resultat' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::indexAction',  '_route' => 'resultat_index',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_resultat_index;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'resultat_index'));
                    }

                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_resultat_index;
                    }

                    return $ret;
                }
                not_resultat_index:

                // resultat_export
                if (preg_match('#^/resultat/(?P<idetudiant>[^/]++)/export$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'resultat_export']), array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::exportAction',));
                }

                // resultat_affiche
                if ('/resultat/affiche' === $pathinfo) {
                    $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::resutlatEtudiantAction',  '_route' => 'resultat_affiche',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_resultat_affiche;
                    }

                    return $ret;
                }
                not_resultat_affiche:

                // resultat_deleteall
                if ('/resultat/deleteall' === $pathinfo) {
                    $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::deleteAllAction',  '_route' => 'resultat_deleteall',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_resultat_deleteall;
                    }

                    return $ret;
                }
                not_resultat_deleteall:

                // resultat_sms
                if ('/resultat/sendsms' === $pathinfo) {
                    $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::sendsmsAction',  '_route' => 'resultat_sms',);
                    if (!in_array($requestMethod, ['POST'])) {
                        $allow = array_merge($allow, ['POST']);
                        goto not_resultat_sms;
                    }

                    return $ret;
                }
                not_resultat_sms:

                if (0 === strpos($pathinfo, '/resultat/stat')) {
                    // resultat_statistique
                    if ('/resultat/stat' === $pathinfo) {
                        $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::statistiqueReussiteAction',  '_route' => 'resultat_statistique',);
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_resultat_statistique;
                        }

                        return $ret;
                    }
                    not_resultat_statistique:

                    // ut_statistique
                    if ('/resultat/statistique' === $pathinfo) {
                        $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::statistiqueUserAction',  '_route' => 'ut_statistique',);
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_ut_statistique;
                        }

                        return $ret;
                    }
                    not_ut_statistique:

                }

                // resultat__management
                if ('/resultat/manage' === $pathinfo) {
                    $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::gererResultatsAction',  '_route' => 'resultat__management',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_resultat__management;
                    }

                    return $ret;
                }
                not_resultat__management:

                // resultat_calculer
                if ('/resultat/calculer' === $pathinfo) {
                    return array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::calculerAction',  '_route' => 'resultat_calculer',);
                }

                // resultat_print
                if ('/resultat/print' === $pathinfo) {
                    return array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::pfdAction',  '_route' => 'resultat_print',);
                }

                // resultat_detail
                if (preg_match('#^/resultat/(?P<idetudiant>[^/]++)/detail$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'resultat_detail']), array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::detailResultatAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_resultat_detail;
                    }

                    return $ret;
                }
                not_resultat_detail:

                // resultat_delete
                if (preg_match('#^/resultat/(?P<idetudiant>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'resultat_delete']), array (  '_controller' => 'evaluationsBundle\\Controller\\ResultatController::deleteAction',));
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_resultat_delete;
                    }

                    return $ret;
                }
                not_resultat_delete:

            }

            elseif (0 === strpos($pathinfo, '/resetting')) {
                // fos_user_resetting_request
                if ('/resetting/request' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.resetting.controller:requestAction',  '_route' => 'fos_user_resetting_request',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_user_resetting_request;
                    }

                    return $ret;
                }
                not_fos_user_resetting_request:

                // fos_user_resetting_reset
                if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_user_resetting_reset']), array (  '_controller' => 'fos_user.resetting.controller:resetAction',));
                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_fos_user_resetting_reset;
                    }

                    return $ret;
                }
                not_fos_user_resetting_reset:

                // fos_user_resetting_send_email
                if ('/resetting/send-email' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.resetting.controller:sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                    if (!in_array($requestMethod, ['POST'])) {
                        $allow = array_merge($allow, ['POST']);
                        goto not_fos_user_resetting_send_email;
                    }

                    return $ret;
                }
                not_fos_user_resetting_send_email:

                // fos_user_resetting_check_email
                if ('/resetting/check-email' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.resetting.controller:checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_user_resetting_check_email;
                    }

                    return $ret;
                }
                not_fos_user_resetting_check_email:

            }

            elseif (0 === strpos($pathinfo, '/register')) {
                // fos_user_registration_register
                if ('/register' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'fos_user.registration.controller:registerAction',  '_route' => 'fos_user_registration_register',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_fos_user_registration_register;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'fos_user_registration_register'));
                    }

                    if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                        $allow = array_merge($allow, ['GET', 'POST']);
                        goto not_fos_user_registration_register;
                    }

                    return $ret;
                }
                not_fos_user_registration_register:

                // fos_user_registration_check_email
                if ('/register/check-email' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.registration.controller:checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                    if (!in_array($canonicalMethod, ['GET'])) {
                        $allow = array_merge($allow, ['GET']);
                        goto not_fos_user_registration_check_email;
                    }

                    return $ret;
                }
                not_fos_user_registration_check_email:

                if (0 === strpos($pathinfo, '/register/confirm')) {
                    // fos_user_registration_confirm
                    if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                        $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_user_registration_confirm']), array (  '_controller' => 'fos_user.registration.controller:confirmAction',));
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_fos_user_registration_confirm;
                        }

                        return $ret;
                    }
                    not_fos_user_registration_confirm:

                    // fos_user_registration_confirmed
                    if ('/register/confirmed' === $pathinfo) {
                        $ret = array (  '_controller' => 'fos_user.registration.controller:confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                        if (!in_array($canonicalMethod, ['GET'])) {
                            $allow = array_merge($allow, ['GET']);
                            goto not_fos_user_registration_confirmed;
                        }

                        return $ret;
                    }
                    not_fos_user_registration_confirmed:

                }

            }

        }

        elseif (0 === strpos($pathinfo, '/rate')) {
            // rate_index
            if ('/rate' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'EvenementBundle\\Controller\\RateController::indexAction',  '_route' => 'rate_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_rate_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'rate_index'));
                }

                return $ret;
            }
            not_rate_index:

            // club_detail
            if (0 === strpos($pathinfo, '/rate/club') && preg_match('#^/rate/club/(?P<idclub>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'club_detail']), array (  '_controller' => 'EvenementBundle\\Controller\\RateController::newAction',));
            }

            // club_rate
            if (preg_match('#^/rate/(?P<idclub>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'club_rate']), array (  '_controller' => 'EvenementBundle\\Controller\\RateController::new2Action',));
            }

            // rate_show
            if (preg_match('#^/rate/(?P<idrating>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'rate_show']), array (  '_controller' => 'EvenementBundle\\Controller\\RateController::showAction',));
            }

            // rate_edit
            if (preg_match('#^/rate/(?P<idrating>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'rate_edit']), array (  '_controller' => 'EvenementBundle\\Controller\\RateController::editAction',));
            }

            // rate_delete
            if (preg_match('#^/rate/(?P<idrating>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'rate_delete']), array (  '_controller' => 'EvenementBundle\\Controller\\RateController::deleteAction',));
            }

        }

        // reclamation_homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'ReclamationBundle\\Controller\\DefaultController::indexAction',  '_route' => 'reclamation_homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_reclamation_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'reclamation_homepage'));
            }

            return $ret;
        }
        not_reclamation_homepage:

        // afficher_user
        if ('/user/user/afficher' === $pathinfo) {
            return array (  '_controller' => 'UserBundle\\Controller\\UserController::afficherAction',  '_route' => 'afficher_user',);
        }

        // profile_user
        if ('/user/user/profile' === $pathinfo) {
            return array (  '_controller' => 'UserBundle\\Controller\\UserController::profileAction',  '_route' => 'profile_user',);
        }

        // evaluations_homepage
        if ('/home' === $pathinfo) {
            return array (  '_controller' => 'evaluationsBundle\\Controller\\DefaultController::indexAction',  '_route' => 'evaluations_homepage',);
        }

        if (0 === strpos($pathinfo, '/note')) {
            // note_index
            if ('/note' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\NoteController::indexAction',  '_route' => 'note_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_note_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'note_index'));
                }

                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_note_index;
                }

                return $ret;
            }
            not_note_index:

            // note_show
            if (preg_match('#^/note/(?P<etudiant>[^/]++)/show$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'note_show']), array (  '_controller' => 'evaluationsBundle\\Controller\\NoteController::showAction',));
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_note_show;
                }

                return $ret;
            }
            not_note_show:

            // note_affiche_etudiant
            if ('/note/notesetudiant' === $pathinfo) {
                $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\NoteController::noteEtudiantAction',  '_route' => 'note_affiche_etudiant',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_note_affiche_etudiant;
                }

                return $ret;
            }
            not_note_affiche_etudiant:

            // note_affiche_enseignant
            if ('/note/notesenseignant' === $pathinfo) {
                $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\NoteController::noteEnseignantAction',  '_route' => 'note_affiche_enseignant',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_note_affiche_enseignant;
                }

                return $ret;
            }
            not_note_affiche_enseignant:

            // note_read
            if ('/note/read' === $pathinfo) {
                $ret = array (  '_controller' => 'evaluationsnBundle:Note:index',  '_route' => 'note_read',);
                if (!in_array($canonicalMethod, ['GET'])) {
                    $allow = array_merge($allow, ['GET']);
                    goto not_note_read;
                }

                return $ret;
            }
            not_note_read:

            // note_new
            if ('/note/add' === $pathinfo) {
                $ret = array (  '_controller' => 'evaluationsBundle\\Controller\\NoteController::addAction',  '_route' => 'note_new',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_note_new;
                }

                return $ret;
            }
            not_note_new:

            // note_edit
            if (preg_match('#^/note/(?P<idetudiant>[^/]++)/(?P<idmatiere>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'note_edit']), array (  '_controller' => 'evaluationsBundle\\Controller\\NoteController::editAction',));
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_note_edit;
                }

                return $ret;
            }
            not_note_edit:

            // note_delete
            if (preg_match('#^/note/(?P<idetudiant>[^/]++)/(?P<idmatiere>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'note_delete']), array (  '_controller' => 'evaluationsBundle\\Controller\\NoteController::deleteAction',));
            }

        }

        // homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'homepage'));
            }

            return $ret;
        }
        not_homepage:

        if (0 === strpos($pathinfo, '/login')) {
            // fos_user_security_login
            if ('/login' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.security.controller:loginAction',  '_route' => 'fos_user_security_login',);
                if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                    $allow = array_merge($allow, ['GET', 'POST']);
                    goto not_fos_user_security_login;
                }

                return $ret;
            }
            not_fos_user_security_login:

            // fos_user_security_check
            if ('/login_check' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.security.controller:checkAction',  '_route' => 'fos_user_security_check',);
                if (!in_array($requestMethod, ['POST'])) {
                    $allow = array_merge($allow, ['POST']);
                    goto not_fos_user_security_check;
                }

                return $ret;
            }
            not_fos_user_security_check:

        }

        // fos_user_security_logout
        if ('/logout' === $pathinfo) {
            $ret = array (  '_controller' => 'fos_user.security.controller:logoutAction',  '_route' => 'fos_user_security_logout',);
            if (!in_array($canonicalMethod, ['GET', 'POST'])) {
                $allow = array_merge($allow, ['GET', 'POST']);
                goto not_fos_user_security_logout;
            }

            return $ret;
        }
        not_fos_user_security_logout:

        if (0 === strpos($pathinfo, '/demandeevenement')) {
            // demandeevenement_index
            if ('/demandeevenement' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'EvenementBundle\\Controller\\DemandeevenementController::indexAction',  '_route' => 'demandeevenement_index',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_demandeevenement_index;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'demandeevenement_index'));
                }

                return $ret;
            }
            not_demandeevenement_index:

            // demandeevenement_new
            if ('/demandeevenement/new' === $pathinfo) {
                return array (  '_controller' => 'EvenementBundle\\Controller\\DemandeevenementController::newAction',  '_route' => 'demandeevenement_new',);
            }

            // demandeevenement_show
            if (preg_match('#^/demandeevenement/(?P<iddemandeevenement>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'demandeevenement_show']), array (  '_controller' => 'EvenementBundle\\Controller\\DemandeevenementController::showAction',));
            }

            // demandeevenement_edit
            if (preg_match('#^/demandeevenement/(?P<iddemandeevenement>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'demandeevenement_edit']), array (  '_controller' => 'EvenementBundle\\Controller\\DemandeevenementController::editAction',));
            }

            // demandeevenement_delete
            if (preg_match('#^/demandeevenement/(?P<iddemandeevenement>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'demandeevenement_delete']), array (  '_controller' => 'EvenementBundle\\Controller\\DemandeevenementController::deleteAction',));
            }

            // demandeevenement_valider
            if (preg_match('#^/demandeevenement/(?P<iddemandeevenement>[^/]++)/valider$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'demandeevenement_valider']), array (  '_controller' => 'EvenementBundle\\Controller\\DemandeevenementController::edit2Action',));
            }

        }

        elseif (0 === strpos($pathinfo, '/question')) {
            // view_questions
            if ('/questions' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'ForumBundle\\Controller\\QuestionController::viewQuestionsAction',  '_route' => 'view_questions',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_view_questions;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'view_questions'));
                }

                return $ret;
            }
            not_view_questions:

            // view_question
            if (preg_match('#^/question/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'view_question']), array (  '_controller' => 'ForumBundle\\Controller\\QuestionController::viewQuestionAction',));
            }

            // edit_question
            if (preg_match('#^/question/(?P<id>[^/]++)/edit$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'edit_question']), array (  '_controller' => 'ForumBundle\\Controller\\QuestionController::editQuestionAction',));
            }

            // delete_question
            if (preg_match('#^/question/(?P<id>[^/]++)/delete$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => 'delete_question']), array (  '_controller' => 'ForumBundle\\Controller\\QuestionController::deleteQuestionAction',));
            }

        }

        // fos_js_routing_js
        if (0 === strpos($pathinfo, '/js/routing') && preg_match('#^/js/routing(?:\\.(?P<_format>js|json))?$#sD', $pathinfo, $matches)) {
            $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'fos_js_routing_js']), array (  '_controller' => 'fos_js_routing.controller:indexAction',  '_format' => 'js',));
            if (!in_array($canonicalMethod, ['GET'])) {
                $allow = array_merge($allow, ['GET']);
                goto not_fos_js_routing_js;
            }

            return $ret;
        }
        not_fos_js_routing_js:

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
