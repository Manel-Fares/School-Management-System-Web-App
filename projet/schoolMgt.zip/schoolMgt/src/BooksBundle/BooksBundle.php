<?php

namespace BooksBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BooksBundle extends Bundle
{
}
