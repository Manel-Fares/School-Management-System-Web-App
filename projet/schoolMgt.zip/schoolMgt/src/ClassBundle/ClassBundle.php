<?php

namespace ClassBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ClassBundle extends Bundle
{
}
