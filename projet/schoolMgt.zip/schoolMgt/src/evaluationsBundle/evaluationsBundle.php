<?php

namespace evaluationsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class evaluationsBundle extends Bundle
{
}
