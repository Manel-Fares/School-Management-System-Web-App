<?php

namespace ReclamationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ReclamationBundle extends Bundle
{
}
