<?php


namespace EvenementBundle\Controller;

use Doctrine\ORM\EntityRepository;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class NotificationController  extends Controller
{
public  function displaAction()
{
}

}